function T12 = jointToTransform12(q)
  % Input: joint angles
  % Output: homogeneous transformation Matrix from frame 2 to frame 1. T_12
  if (length(q)>1)
  	q = q(2);
  end
  T12 = [ cos(q), -sin(q), 0,     0;
          sin(q), cos(q),      0,     0;
          0, 0, 1, 0;
               0, 0,      0,     1];
     
end

